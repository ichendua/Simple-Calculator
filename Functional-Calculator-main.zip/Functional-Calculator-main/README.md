# Funtional-Calculator-
My first ever built calculator. It has every part a calculator possesses....Built with HTML, CSS, JAVASCRIPT. 
Simple-Calculator

A simple non functional Calculator for general purposes.

Why use it?
Its useful for simple calculations.

Features
Add
Multiply
Subtract
Divide
Built With
html
css
How to Run?
To run my application you simply need to clone the project and run the html file
Issues
Internet Explorer you need to allow all the scripts to run.
Not working in Mozilla.
Feel free to submit more issues and enhancement requests.
Contributing
Any kind of contributions are welcome.

Fork the repo on GitHub.
Clone the project to your own machine.
Commit changes to development branch.
Push your work back up to your fork.
Submit a Pull request so that i can review your changes

Copyright (c) 2023 PHILIP RUKY VICTORY

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.